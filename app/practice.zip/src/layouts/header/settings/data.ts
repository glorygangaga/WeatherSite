export const buttons: string[] = ['Светлая', 'Темная'] as const;
