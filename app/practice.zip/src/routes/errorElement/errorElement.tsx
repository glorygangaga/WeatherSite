import type { FC } from 'react';

const ErrorElement: FC = () => {
  return <div>ErrorElement</div>;
};

export default ErrorElement;
